PROJECT NAME: Retail Business Performance & Profitability Analysis (Superstore Sales Data)

OBJECTIVE:
To analyze Superstore sales data to identify profit-draining categories, low-performing regions, and seasonal patterns using Python and Power BI. The goal is to uncover actionable insights to improve business profitability.

FILES INCLUDED:
1. Superstore_Project_Report.pdf – Final 1-page project report
2. Superstore_Analysis.ipynb – Python notebook used for EDA and correlation analysis
3. Superstore_Dashboard.pbix – Power BI file with interactive dashboard
4. README.txt – This file describing project structure and deliverables

TOOLS USED:
- Python (Google Colab – using Pandas, Seaborn, Matplotlib)
- Power BI Desktop (for dashboard)
- Dataset: SampleSuperstore.csv (Kaggle open dataset)

PROJECT WORK SUMMARY:
- Cleaned the dataset using Python and removed unnecessary columns.
- Explored sales, profit, discount, and regional performance using graphs.
- Created a Power BI dashboard showing profit/loss by category, sub-category, region, and trends over time.
- Applied filters in Power BI to explore data by Segment, Category, Region, and Quarter.

KEY INSIGHTS:
- Tables and Bookcases are loss-making sub-categories.
- Technology products contribute the highest profits.
- Central and South regions underperform compared to West and East.
- Higher discounts are linked to reduced profitability.

RECOMMENDATIONS:
- Reduce discount percentages on products with consistently low profit.
- Focus marketing on high-margin items (e.g., Copiers, Phones).
- Reevaluate inventory planning for slow-moving or unprofitable items.
- Improve sales strategy for Central region through region-specific offers.

NOTE:
This project was submitted as part of a 2-week internship. The dataset used is public and modified for academic purposes.
